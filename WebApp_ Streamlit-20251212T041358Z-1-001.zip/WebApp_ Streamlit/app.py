import streamlit as st
import torch
import torch.nn as nn
import numpy as np
from sentence_transformers import SentenceTransformer
from transformers import T5Tokenizer, T5EncoderModel

# ----------------------------
# 1️⃣ Load Embedding Models
# ----------------------------
@st.cache_resource
def load_embedding_models():
    # FIXED: Use 768-dim BERT model (matches your trained model)
    bert = SentenceTransformer("sentence-transformers/paraphrase-multilingual-mpnet-base-v2")

    t5_tokenizer = T5Tokenizer.from_pretrained("google/mt5-base")
    t5_encoder = T5EncoderModel.from_pretrained("google/mt5-base")
    return bert, t5_tokenizer, t5_encoder


bert_model, t5_tokenizer, t5_encoder = load_embedding_models()

# ----------------------------
# 2️⃣ TransformNeuNetANN Model
# ----------------------------
class TransformNeuNetANN(nn.Module):
    def __init__(self, bert_dim=768, t5_dim=768, num_classes=10, hidden_dim=256):
        super().__init__()

        # BERT branch
        self.bert_fc = nn.Sequential(
            nn.Linear(bert_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3)
        )

        # T5 branch
        self.t5_fc = nn.Sequential(
            nn.Linear(t5_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3)
        )

        # Combined fully connected layers
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )

    def forward(self, bert_feat, t5_feat):
        bert_out = self.bert_fc(bert_feat)
        t5_out = self.t5_fc(t5_feat)
        combined = torch.cat([bert_out, t5_out], dim=1)
        out = self.fc(combined)
        return out


# ----------------------------
# 3️⃣ Load Saved Model
# ----------------------------
@st.cache_resource
def load_model():
    checkpoint = torch.load("/content/transform_neunet_model.pth", map_location="cpu")

    bert_dim = checkpoint["bert_dim"]
    t5_dim = checkpoint["t5_dim"]
    num_classes = checkpoint["num_classes"]
    hidden_dim = checkpoint["hidden_dim"]
    label_classes = checkpoint["label_encoder_classes"]

    # rebuild model
    model = TransformNeuNetANN(
        bert_dim=bert_dim,
        t5_dim=t5_dim,
        hidden_dim=hidden_dim,
        num_classes=num_classes
    )

    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    return model, label_classes


model, label_classes = load_model()


# ----------------------------
# 4️⃣ Embed Text
# ----------------------------
def get_embeddings(text):
    # BERT embedding (now correctly 768-dim)
    bert_vec = bert_model.encode(text)
    bert_vec = np.array(bert_vec, dtype="float32")

    # T5 embedding
    tokens = t5_tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    with torch.no_grad():
        t5_output = t5_encoder(**tokens).last_hidden_state
        t5_vec = t5_output.mean(dim=1).squeeze().numpy()

    return bert_vec, t5_vec


# ----------------------------
# 5️⃣ Predict Category
# ----------------------------
def predict(text):
    bert_vec, t5_vec = get_embeddings(text)

    bert_tensor = torch.tensor([bert_vec], dtype=torch.float32)
    t5_tensor = torch.tensor([t5_vec], dtype=torch.float32)

    with torch.no_grad():
        logits = model(bert_tensor, t5_tensor)
        probs = torch.softmax(logits, dim=1).numpy()[0]

    pred_idx = np.argmax(probs)
    pred_label = label_classes[pred_idx]

    return pred_label, probs


# ----------------------------
# 6️⃣ Modern UI CSS
# ----------------------------

st.markdown("""
<style>
/* Center title */
h1 { text-align: center; margin-bottom: 10px; }

/* Card container */
.card {
    padding: 18px 20px;
    border-radius: 12px;
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    box-shadow: 0 3px 8px rgba(0,0,0,0.04);
    margin: 0; 
}

/* Remove blank spacing Streamlit adds */
.block-container {
    padding-top: 20px;
    padding-bottom: 20px;
    margin-top: -10px;
}

/* Cleaner button */
.stButton>button {
    background: linear-gradient(90deg, #4A90E2, #357ABD);
    color: white;
    border-radius: 10px;
    padding: 10px 26px;
    font-size: 17px;
    border: none;
    cursor: pointer;
    transition: 0.2s ease-in-out;
}

.stButton>button:hover {
    transform: scale(1.05);
    filter: brightness(1.08);
}

/* Result label */
.result-label {
    font-size: 20px;
    font-weight: 600;
    color: #1E8B4E;
    margin-bottom: 6px;
}
</style>
""", unsafe_allow_html=True)


# Title
st.markdown(
    "<h1>Bangla Texts Category Classification</h1>",
    unsafe_allow_html=True
)

# Create two columns (input left, results right)
# Create three columns: left, gap, right
col1, gap, col2 = st.columns([2, 0.5, 1.75])


# ---------- LEFT: INPUT ----------
with col1:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("#### ✍️ Enter Bangla News Article")
    user_input = st.text_area(
        "", 
        height=350, 
        label_visibility="collapsed"
    )
    
    predict_clicked = st.button("🔍 Predict Category")
    st.markdown("</div>", unsafe_allow_html=True)

# ---------- RIGHT: RESULTS ----------
with col2:
    if predict_clicked:
        if user_input.strip() == "":
            st.warning("Please enter some text!")
        else:
            pred_label, probs = predict(user_input)

            st.markdown("<div class='card'>", unsafe_allow_html=True)

            st.markdown(
                f"<p class='result-label'>✅ Predicted Category: <b>{pred_label}</b></p>",
                unsafe_allow_html=True
            )

            st.markdown("#### Confidence Scores")
            for label, score in zip(label_classes, probs):
                st.write(f"**{label}** → {score*100:.2f}%")

            st.markdown("</div>", unsafe_allow_html=True)


